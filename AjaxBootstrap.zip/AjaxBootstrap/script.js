$(document).on('submit', '#saveStudent' ,function(e)
{   
    e.preventDefault(); 

    var formData = new FormData(this); 
    formData.append("save_student", true);  

    $.ajax({    
       type: "POST" ,
       url:  "action.php",
       data: formData, 
       processData: false, 
       contentType:false,
       success: function(response)
       {    
         var res = jQuery.parseJSON(response);  
         if(res.status == 422)
         {  
            $("#errorMessage").removeClass('d-none'); 
            $("#errorMessage").text(res.message);
         }
       }
    });
});