<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="./vendor/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
</head>

<body>      
    <?php   
        include './modal.php';
    ?>
    <div class="container">    
        <div class="row">   
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Ajax And Bootstrap</h4> 
                <!-- Button trigger modal -->
                     <button type="button" 
                        class="btn btn-primary" id="btnAddUser" data-bs-toggle="modal" data-bs-target="#addUser">
                        Launch demo modal
                    </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="./vendor/bootstrap.bundle.min.js"></script>
    <script src="./vendor/jquery.min.js"></script> 
    <script src="./script.js"></script>
</body>

</html>